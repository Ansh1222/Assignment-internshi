from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse, redirect
from django.shortcuts import render
import razorpay
from django.views.decorators.csrf import csrf_exempt

# Create your views here.


def index(request):
    if request.method == 'POST':
        amount = 50000
        order_currency = 'INR'
        client = razorpay.Client(
            auth=('rzp_test_hHS1pvTmMXgUmm', '2u1CMn0npXcHXQ4DMgLNApyd')
        )
        payment = client.order.create({'amount': amount, 'currency': 'INR'})
    return render(request, 'home.html')


@csrf_exempt
def success(request):
    return render(request, 'success.html')
